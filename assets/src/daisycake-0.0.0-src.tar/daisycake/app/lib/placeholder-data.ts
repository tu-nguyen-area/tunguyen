export const clImage = [
  { 
    id: '1',
    name: 'Cakeline1',
    url: '/cakeline1.png',
  },
  { 
    id: '2',
    name: 'Cakeline2',
    url: '/cakeline2.png',
  },
  {
    id: '3',
    name: 'Cakeline3',
    url: '/cakeline3.png',
  },
  {
    id: '4',
    name: 'Cakeline4',
    url: '/cakeline4.png',
  },
  {
    id: '5',
    name: 'Cakeline5',
    url: '/cakeline5.png',
  },
  {
    id: '6',
    name: 'Cakeline6',
    url: '/cakeline6.png',
  },
  {
    id: '7',
    name: 'Cakeline7',
    url: '/cakeline7.png',
  },
];
