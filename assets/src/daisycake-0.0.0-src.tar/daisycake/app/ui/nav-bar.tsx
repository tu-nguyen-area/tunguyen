export default function NavBar() {
  return (
    <>
      <div>
        <h1>
          NavBar
        </h1>
      </div>
    </>
  );
}
