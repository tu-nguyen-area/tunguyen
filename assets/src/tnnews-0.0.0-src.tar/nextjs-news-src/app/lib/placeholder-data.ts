const posts = [
  {
    id: '1',
    title: 'title1',
    author: 'author1',
    content: 'content1',
  },
  {
    id: '2',
    title: 'title2',
    author: 'author2',
    content: 'content2',
  },
  {
    id: '3',
    title: 'title3',
    author: 'author3',
    content: 'content3',
  },
];

export { posts };
