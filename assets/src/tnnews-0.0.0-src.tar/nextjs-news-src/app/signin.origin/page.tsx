import SigninForm from '@/app/ui/signin-form';

export default function Page() {
  return (
  <>
    <div>
      <SigninForm />
    </div>
  </>
  );
}
