export default function Page() {
  return (
  <>
    <div>
      Sign Up
    </div>
  </>
  );
}
