export default function Comment() {
  return (
  <>
    <div>Comments</div>
  </>
  );
}
